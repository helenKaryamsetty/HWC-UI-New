/*
 * AMRIT – Accessible Medical Records via Integrated Technology
 * Integrated EHR (Electronic Health Records) Solution
 *
 * Copyright (C) "Piramal Swasthya Management and Research Institute"
 *
 * This file is part of AMRIT.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see https://www.gnu.org/licenses/.
 */
import { Component, DoCheck, Inject, OnInit, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { ConfirmationService } from '../../services/confirmation.service';
import { DatePipe } from '@angular/common';
import { SetLanguageComponent } from '../set-language.component';
import { HealthIdValidateComponent } from 'src/app/app-modules/registrar/registration/register-other-details/register-other-details.component';
import {
  MAT_DIALOG_DATA,
  MatDialog,
  MatDialogRef,
} from '@angular/material/dialog';
import { HttpServiceService } from '../../services/http-service.service';
import { RegistrarService } from '../../services/registrar.service';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';

@Component({
  selector: 'app-health-id-display-modal',
  templateUrl: './health-id-display-modal.component.html',
  styleUrls: ['./health-id-display-modal.component.css'],
  providers: [DatePipe],
})
export class HealthIdDisplayModalComponent implements OnInit, DoCheck {
  healthIDArray: any = [];
  chooseHealthID: any;
  currentLanguageSet: any;
  healthIDMapped: any;
  benDetails: any;
  enablehealthIdOTPForm = false;
  healthIDMapping = false;
  transactionId: any;
  selectedHealthID: any;
  healthIdOTPForm!: FormGroup;
  showProgressBar = false;
  searchDetails: any = [];
  searchPopup = false;

  displayedColumns: string[] = [
    'sno',
    'abhaNumber',
    'abha',
    'dateOfCreation',
    'abhaMode',
  ];
  dataSource = new MatTableDataSource<any>([]);
  @ViewChild(MatPaginator) paginator: MatPaginator | null = null;

  constructor(
    public dialogRef: MatDialogRef<HealthIdDisplayModalComponent>,
    @Inject(MAT_DIALOG_DATA) public input: any,
    public httpServiceService: HttpServiceService,
    private formBuilder: FormBuilder,
    private registrarService: RegistrarService,
    private confirmationService: ConfirmationService,
    private datePipe: DatePipe,
    private dialogMd: MatDialog,
  ) {
    dialogRef.disableClose = true;
  }

  ngOnInit() {
    console.log('datalist', this.input);
    this.searchDetails = null;
    this.selectedHealthID = null;
    this.searchPopup = false;
    this.assignSelectedLanguage();
    this.searchPopup =
      this.input.search != undefined ? this.input.search : false;
    // this.httpServiceService.currentLangugae$.subscribe(response => this.currentLanguageSet = response);
    this.healthIDMapping = this.input.healthIDMapping;
    if (
      this.input.dataList != undefined &&
      this.input.dataList.length > 0 &&
      this.input.search == true
    )
      this.searchDetails = this.input.dataList;
    if (
      this.input.dataList != undefined &&
      this.input.dataList.data != undefined &&
      this.input.dataList.data.BenHealthDetails != undefined
    )
      this.benDetails = this.input.dataList.data.BenHealthDetails;
    this.healthIdOTPForm = this.createOtpGenerationForm();
    this.createList();
  }
  ngDoCheck() {
    this.assignSelectedLanguage();
  }
  assignSelectedLanguage() {
    const getLanguageJson = new SetLanguageComponent(this.httpServiceService);
    getLanguageJson.setLanguage();
    this.currentLanguageSet = getLanguageJson.currentLanguageObject;
  }
  createOtpGenerationForm() {
    return this.formBuilder.group({
      otp: null,
    });
  }
  createList() {
    if (this.benDetails.length > 0) {
      this.benDetails.forEach((healthID: any) => {
        healthID.createdDate = this.datePipe.transform(
          healthID.createdDate,
          'yyyy-MM-dd hh:mm:ss a',
        );
        // let date = new Date(healthID.createdDate);
        // let mnth = ("0" + (date.getMonth() + 1)).slice(-2),
        //   day = ("0" + date.getDate()).slice(-2);
        // let newDate = [day, mnth, date.getFullYear()].join("-");
        // healthID.createdDate = newDate;
        this.healthIDArray.push(healthID);
      });
    }
  }
  onRadioChange(data: any) {
    this.selectedHealthID = data;
  }
  generateOtpForMapping() {
    this.showProgressBar = true;
    const reqObj = {
      healthID: this.selectedHealthID.healthId
        ? this.selectedHealthID.healthId
        : null,
      healthIdNumber: this.selectedHealthID.healthIdNumber
        ? this.selectedHealthID.healthIdNumber
        : null,
      authenticationMode: this.selectedHealthID.authenticationMode,
    };
    this.registrarService.generateOtpForMappingCareContext(reqObj).subscribe(
      (receivedOtpResponse) => {
        if (receivedOtpResponse.statusCode == 200) {
          this.showProgressBar = false;
          this.confirmationService.alert(
            this.currentLanguageSet.OTPSentToRegMobNo,
            'success',
          );
          this.transactionId = receivedOtpResponse.data.txnId;
          this.enablehealthIdOTPForm = true;
        } else {
          this.confirmationService.alert(
            receivedOtpResponse.errorMessage,
            'error',
          );
          this.enablehealthIdOTPForm = false;
          this.showProgressBar = false;
        }
      },
      (err) => {
        this.showProgressBar = false;
        this.confirmationService.alert(err.errorMessage, 'error');
        this.enablehealthIdOTPForm = false;
      },
    );
  }
  numberOnly(event: any): boolean {
    const charCode = event.which ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }
  checkOTP() {
    const otp = this.healthIdOTPForm.controls['otp'].value;
    let cflag = false;
    if (otp != '' && otp != undefined && otp != null) {
      const hid = otp;
      if (hid.length >= 4 && hid.length <= 32) {
        for (let i = 0; i < hid.length; i++) {
          if (!this.is_numeric(hid.charAt(i))) {
            cflag = true;
            break;
          }
        }
        if (cflag) return false;
      } else return false;
    } else return false;
    return true;
  }
  isLetter(str: any) {
    return str.length === 1 && str.match(/[a-z]/i);
  }
  is_numeric(str: any) {
    return /^\d+$/.test(str);
  }

  verifyOtp() {
    this.showProgressBar = true;
    const verifyOtpData = {
      otp: this.healthIdOTPForm.controls['otp'].value,
      txnId: this.transactionId,
      beneficiaryID: this.selectedHealthID.beneficiaryRegID,
      healthID: this.selectedHealthID.healthId
        ? this.selectedHealthID.healthId
        : null,
      healthIdNumber: this.selectedHealthID.healthIdNumber
        ? this.selectedHealthID.healthIdNumber
        : null,
      visitCode: this.input.visitCode,
      visitCategory:
        localStorage.getItem('visiCategoryANC') === 'General OPD (QC)'
          ? 'Emergency'
          : localStorage.getItem('visiCategoryANC'),
    };
    this.registrarService
      .verifyOtpForMappingCarecontext(verifyOtpData)
      .subscribe(
        (verifiedMappingData) => {
          if (verifiedMappingData.statusCode == 200) {
            this.showProgressBar = false;
            this.confirmationService.alert(
              verifiedMappingData.data.response,
              'success',
            );
            this.closeDialog();
          } else {
            this.showProgressBar = false;
            this.confirmationService.alert(
              verifiedMappingData.errorMessage,
              'error',
            );
          }
        },
        (err) => {
          this.showProgressBar = false;
          this.confirmationService.alert(err.errorMessage, 'error');
        },
      );
  }
  resendOtp() {
    this.healthIdOTPForm.controls['otp'].reset;
    this.healthIdOTPForm.controls['otp'].patchValue(null);
    this.generateOtpForMapping();
  }
  closeDialog() {
    this.dialogRef.close();
  }

  openDialogForprintHealthIDCard(data: any, txnId: any) {
    const dialogRefValue = this.dialogMd.open(HealthIdValidateComponent, {
      height: '250px',
      width: '420px',
      disableClose: true,
      data: {
        healthId: data.healthId,
        authenticationMode: data.authenticationMode,
        generateHealthIDCard: true,
        healthIDDetailsTxnID: txnId,
      },
    });

    dialogRefValue.afterClosed().subscribe((result) => {
      console.log('result', result);
    });

    // this.closeDialog();
  }

  printHealthIDCard(data: any) {
    let healthMode: any = null;
    if (
      data.authenticationMode !== undefined &&
      data.authenticationMode !== null &&
      data.authenticationMode === 'AADHAR'
    )
      healthMode = 'AADHAAR';
    else if (
      data.authenticationMode !== undefined &&
      data.authenticationMode !== null &&
      data.authenticationMode === 'MOBILE'
    )
      healthMode = 'MOBILE';

    this.showProgressBar = true;
    const reqObj = {
      authMethod:
        healthMode != null && healthMode != undefined
          ? healthMode + '_OTP'
          : null,
      healthid: data.healthId,
      healthIdNumber: data.healthIdNumber,
    };
    this.registrarService.generateHealthIDCard(reqObj).subscribe(
      (res) => {
        if (res.statusCode == 200 && Object.keys(res.data).length > 0) {
          this.dialogRef.close();
          // this.confirmationService.confirmHealthId('success', this.currentLanguageSet.OTPSentToRegMobNo).subscribe((result) => {
          //   if(result)
          //   {
          this.dialogRef.afterClosed().subscribe((result) => {
            // console.log('result', result)
            this.transactionId = res.data.txnId;
            if (healthMode == 'MOBILE') {
              this.confirmationService
                .confirmHealthId(
                  'success',
                  this.currentLanguageSet.OTPSentToRegMobNo,
                )
                .subscribe((result) => {
                  if (result) {
                    this.openDialogForprintHealthIDCard(
                      data,
                      this.transactionId,
                    );
                  }
                });
            } else if (healthMode == 'AADHAAR') {
              this.confirmationService
                .confirmHealthId(
                  'success',
                  this.currentLanguageSet.OTPSentToAadharLinkedNo,
                )
                .subscribe((result) => {
                  if (result) {
                    this.openDialogForprintHealthIDCard(
                      data,
                      this.transactionId,
                    );
                  }
                });
            }
          });

          // }
          this.showProgressBar = false;
          // });
        } else {
          // let dat={
          //   "clearHealthID":true
          // };
          this.showProgressBar = false;
          // this.dialogRef.close();
          this.confirmationService.alert(res.status, 'error');
        }
      },
      (err) => {
        this.showProgressBar = false;
        this.confirmationService.alert(err.errorMessage, 'error');
      },
    );
  }
}
